import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from synapsting.analysis import bootstrap_hill, hill

CONDITIONS = {
    "controle": ("A", 0.0),
    "Modo A α=0,1": ("A", 0.1),
    "Modo A α=0,15": ("A", 0.15),
    "Modo A α=0,2": ("A", 0.2),
    "Modo B ρ=0,5": ("B", 0.5),
    "Modo B ρ=1": ("B", 1.0),
}
CIRCUITS = [
    ("Alimentação 100 Hz", "alimentacao", 100, "MN9_hz"),
    ("Alimentação 200 Hz", "alimentacao", 200, "MN9_hz"),
    ("Água 200 Hz", "agua", 200, "MN9_hz"),
    ("Limpeza 200 Hz", "limpeza", 200, "aDN1_hz"),
    ("Limpeza 250 Hz", "limpeza", 250, "aDN1_hz"),
]
TRIALS = 10


def read(folder, name):
    f = folder / f"{name}.csv"
    if not f.exists():
        return None
    d = pd.read_csv(f)
    if "level" in d:
        d["level"] = d.level.astype(float)
    if "trial" in d:
        d = d[d.trial < TRIALS]
    return d


def read_screen(folder):
    single = folder / "gargalos.csv"
    if single.exists():
        return pd.read_csv(single)
    parts = sorted((folder / "gargalos").glob("gargalos_parte*.csv"))
    if not parts:
        return None
    d = pd.concat([pd.read_csv(p) for p in parts], ignore_index=True)
    is_base = d.flywire_id.astype(str) == "baseline"
    return pd.concat([d[is_base].head(1), d[~is_base]], ignore_index=True)


def threshold_figure(feeding, folder):
    blockade = feeding[feeding["mode"] == "A"]
    levels = sorted(blockade.level.unique())
    fits = []
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    for color, alpha in zip(plt.cm.viridis(np.linspace(0, 0.9, len(levels))), levels):
        d = blockade[blockade.level == alpha]
        m = d.groupby("stim_hz").MN9_hz.agg(["mean", "std"])
        ax[0].errorbar(m.index, m["mean"], m["std"], color=color, marker="o", ms=4, capsize=2, label=f"α = {alpha:.2f}")
        fit = bootstrap_hill(d, n_boot=300)
        fit["alpha"] = alpha
        fits.append(fit)
        if fit["ok"]:
            s = np.linspace(0, 200, 200)
            ax[0].plot(s, hill(s, fit["rmax"], fit["s50"], fit["n"]), color=color, lw=1, alpha=0.6)
    ax[0].set(
        xlabel="Estímulo nos GRNs de açúcar (Hz)", ylabel="Taxa do MN9 (Hz)", title="Modo A: bloqueio colinérgico"
    )
    ax[0].legend(fontsize=7)
    table = pd.DataFrame(fits)[["alpha", "s50", "s50_lo", "s50_hi", "rmax", "n", "frac_finite"]]
    ok = table[np.isfinite(table.s50) & (table.rmax < 399)]  # Rmáx no limite do ajuste = S50 não confiável
    ax[1].errorbar(ok.alpha, ok.s50, [ok.s50 - ok.s50_lo, ok.s50_hi - ok.s50], marker="o", capsize=3, color="k")
    ax[1].set(
        xlabel="α (fração de bloqueio das sinapses de ACh)",
        ylabel="S50 (Hz), IC 95%",
        title="Limiar do reflexo no modelo",
        ylim=(0, 240),
    )
    plt.tight_layout()
    plt.savefig(folder / "fig1_curvas_modoA.png", dpi=160)
    plt.close()
    table.round(4).to_csv(folder / "ajustes_modoA.csv", index=False)
    return table


def vulnerability_figure(data, folder):
    rows = []
    for label, name, stim, column in CIRCUITS:
        d = data.get(name)
        if d is None:
            continue
        for condition, (mode, level) in CONDITIONS.items():
            x = d[(d["mode"] == mode) & (d.level == level) & (d.stim_hz == stim)][column]
            if len(x):
                rows.append(
                    dict(
                        circuito=label, condicao=condition, media_hz=round(x.mean(), 1), dp=round(x.std(), 1), n=len(x)
                    )
                )
    summary = pd.DataFrame(rows)
    summary.to_csv(folder / "modoA_vs_B.csv", index=False)
    pivot = summary.pivot(index="circuito", columns="condicao", values="media_hz")
    relative = (pivot.div(pivot["controle"], axis=0) * 100).round(0)
    fig, ax = plt.subplots(figsize=(9, 4))
    relative.drop(columns="controle").plot.bar(ax=ax, rot=0, width=0.8)
    ax.axhline(100, color="k", lw=0.8, ls="--")
    ax.set(ylabel="% da resposta do controle", title="Vulnerabilidade por circuito e mecanismo")
    ax.legend(fontsize=7, ncol=3)
    plt.tight_layout()
    plt.savefig(folder / "fig2_vulnerabilidade.png", dpi=160)
    plt.close()
    return relative


def bottleneck_figure(screen, folder):
    screen = screen[screen.flywire_id.astype(str) != "baseline"].sort_values("drop_pct")
    labels = [f"{t} ({str(i)[-6:]})" for t, i in zip(screen.cell_type.fillna(""), screen.flywire_id)]
    fig, ax = plt.subplots(figsize=(7, max(4.5, 0.22 * len(screen))))
    ax.barh(labels, screen.drop_pct, color="#b5651d")
    ax.set(xlabel="Queda do MN9 ao silenciar o neurônio (%)", title="Triagem de gargalos colinérgicos")
    plt.tight_layout()
    plt.savefig(folder / "fig3_gargalos.png", dpi=160)
    plt.close()


def main():
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else "resultados/preliminar")
    out = folder / "analise" if (folder / "analise").is_dir() else folder
    data = {name: read(folder, name) for name in ["alimentacao", "agua", "limpeza", "embaralhado"]}
    data["gargalos"] = read_screen(folder)
    table = threshold_figure(data["alimentacao"], out)
    relative = vulnerability_figure(data, out)
    if data["gargalos"] is not None:
        if out != folder:
            data["gargalos"].to_csv(out / "gargalos.csv", index=False)
        bottleneck_figure(data["gargalos"], out)
    print(table.round(1).to_string(index=False))
    print()
    print(relative.to_string())
    if data["embaralhado"] is not None:
        shuffled = data["embaralhado"]
        print(
            "\nEmbaralhado, sem bloqueio:",
            shuffled[shuffled.level == 0].groupby("stim_hz")[["MN9_hz", "n_recruited_5hz"]].mean().round(1).to_dict(),
        )


if __name__ == "__main__":
    main()
