import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from synapsting.connectome import load_connectome
from synapsting.neurons import MN9, load_sets
from synapsting.simulator import simulate


def main():
    ap = argparse.ArgumentParser(description="Silencia um neurônio colinérgico por vez e mede a queda do MN9.")
    ap.add_argument("--top", type=int, default=40)
    ap.add_argument("--trials", type=int, default=10)
    ap.add_argument("--rate", type=float, default=100)
    ap.add_argument("--saida", default="final")
    ap.add_argument("--parte", type=int, default=0)
    ap.add_argument("--partes", type=int, default=1)
    a = ap.parse_args()
    con = load_connectome("data", "783")
    cell_types = (
        pd.read_csv("data/flywire_annotations_783.tsv", sep="\t", usecols=["root_id", "cell_type"], low_memory=False)
        .set_index("root_id")
        .cell_type
    )
    sugar, mn9 = con.idx(load_sets()["sugar"]), con.idx([MN9])[0]
    base = simulate(con, sugar, a.rate, n_trials=6, seed=11)
    rate = base.mean(0)
    excluded = set(sugar.tolist()) | {mn9}
    candidates = [i for i in np.argsort(-rate) if con.nt[i] == "acetylcholine" and i not in excluded][: a.top]
    ranked = list(enumerate(candidates))[a.parte :: a.partes]
    base_mn9 = base[:, mn9].mean()
    rows = [dict(flywire_id="baseline", cell_type="", base_rate_hz=np.nan, MN9_hz=base_mn9, drop_pct=0.0)]
    folder = Path("resultados") / a.saida
    folder.mkdir(parents=True, exist_ok=True)
    for j, i in ranked:
        mn9_rate = simulate(con, sugar, a.rate, n_trials=a.trials, silence=[i], seed=100 + j)[:, mn9].mean()
        fid = int(con.ids[i])
        cell_type = cell_types.get(fid)
        rows.append(
            dict(
                flywire_id=fid,
                cell_type=cell_type if isinstance(cell_type, str) else "",
                base_rate_hz=round(rate[i], 1),
                MN9_hz=mn9_rate,
                drop_pct=round(100 * (1 - mn9_rate / base_mn9), 1),
            )
        )
        name = "gargalos.csv" if a.partes == 1 else f"gargalos_parte{a.parte}.csv"
        pd.DataFrame(rows).to_csv(folder / name, index=False)
        print(f"{j + 1}/{len(candidates)} {fid}: MN9 = {mn9_rate:.1f} Hz", flush=True)


if __name__ == "__main__":
    main()
