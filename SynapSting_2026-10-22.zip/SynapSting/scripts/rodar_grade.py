import argparse
import json
import time
from multiprocessing import get_context
from pathlib import Path

import numpy as np
import pandas as pd

from synapsting.connectome import load_connectome
from synapsting.neurons import ABN1, ADN1, MN9, MN9_PAIR, load_sets
from synapsting.perturbations import perturbation, shuffle_connectome, stable_seed
from synapsting.simulator import LIFParams, simulate

READOUTS = {"MN9": [MN9], "MN9pair": MN9_PAIR, "aDN1": [ADN1], "aBN1": [ABN1]}
KEY = ["experiment", "mode", "level", "stim_hz", "rep"]
STATE = {}


def init_worker(version):
    STATE["con"] = load_connectome("data", version)
    STATE["sets"] = {k: STATE["con"].idx(v) for k, v in load_sets().items()}
    STATE["cache"] = {}


def prepared(shuffle_seed, mode, level, params):
    key = (shuffle_seed, mode, level)
    if key not in STATE["cache"]:
        con = STATE["con"] if shuffle_seed is None else shuffle_connectome(STATE["con"], seed=shuffle_seed)
        STATE["cache"] = {k: v for k, v in STATE["cache"].items() if k[0] == shuffle_seed}
        STATE["cache"][key] = (con, *perturbation(con, mode, level, params))
    return STATE["cache"][key]


def run_task(task):
    t0 = time.time()
    p = LIFParams(t_run=task["t_run_ms"])
    con, scale, bias = prepared(task["shuffle_seed"], task["mode"], task["level"], p)
    stim = STATE["sets"][task["stim"]]
    seed = stable_seed(task["experiment"], task["mode"], task["level"], task["stim_hz"], task["rep"])
    counts = simulate(
        con, stim, task["stim_hz"], n_trials=task["trials"], params=p, weight_scale=scale, bias_mv=bias, seed=seed
    )
    seconds = p.t_run / 1000.0
    readouts = {name: con.idx(READOUTS[name]) for name in task["readouts"]}
    stimulated = np.zeros(con.N, bool)
    stimulated[stim] = True
    n_spont = int((bias > p.v_th - p.v0).sum()) if bias is not None else 0
    rows = []
    for k in range(task["trials"]):
        row = {c: task[c] for c in KEY + ["shuffle_seed", "t_run_ms"]}
        row.update(trial=k, seed=seed, n_spontaneous=n_spont)
        for name, idx in readouts.items():
            row[f"{name}_hz"] = counts[k, idx].mean() / seconds
        row["n_recruited_5hz"] = int(((counts[k] / seconds > 5) & ~stimulated).sum())
        row["total_spikes"] = int(counts[k].sum())
        rows.append(row)
    return task, rows, time.time() - t0


def build_tasks(cfg):
    tasks = []
    for ex in cfg["experiments"]:
        for rep, shuffle_seed in enumerate(ex.get("shuffle_seeds", [None])):
            for mode, level in ex["conditions"]:
                for rate in ex["rates"]:
                    trials = ex.get("trials", cfg["trials"])
                    t_run = cfg["t_run_ms"]
                    if mode == "B":
                        trials = ex.get("trials_B", cfg.get("trials_B", trials))
                        t_run = cfg.get("t_run_ms_B", t_run)
                    tasks.append(
                        dict(
                            experiment=ex["name"],
                            stim=ex["stim"],
                            readouts=ex["readouts"],
                            mode=mode,
                            level=float(level),
                            stim_hz=float(rate),
                            rep=rep,
                            shuffle_seed=shuffle_seed,
                            trials=trials,
                            t_run_ms=float(t_run),
                        )
                    )
    return tasks


def done_keys(folder):
    keys = set()
    for f in folder.glob("*.csv"):
        for r in pd.read_csv(f)[KEY].drop_duplicates().itertuples(index=False):
            keys.add((r.experiment, r.mode, float(r.level), float(r.stim_hz), int(r.rep)))
    return keys


def main():
    ap = argparse.ArgumentParser(description="Roda uma grade de simulações em paralelo, com retomada automática.")
    ap.add_argument("config")
    ap.add_argument("--jobs", type=int, default=1)
    a = ap.parse_args()
    cfg = json.loads(Path(a.config).read_text())
    folder = Path("resultados") / cfg["output"]
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "config_usada.json").write_text(json.dumps(cfg, indent=1, ensure_ascii=False))
    tasks = build_tasks(cfg)
    done = done_keys(folder)
    todo = [t for t in tasks if tuple(t[c] for c in KEY) not in done]
    todo.sort(key=lambda t: (t["mode"] != "B", -t["stim_hz"]))
    print(f"{len(tasks)} tarefas, {len(tasks) - len(todo)} já feitas, {len(todo)} a fazer, {a.jobs} processo(s).")
    if not todo:
        return
    t0 = time.time()
    with get_context("spawn").Pool(a.jobs, initializer=init_worker, initargs=(cfg["version"],)) as pool:
        for i, (task, rows, seconds) in enumerate(pool.imap_unordered(run_task, todo), 1):
            out = folder / f"{task['experiment']}.csv"
            pd.DataFrame(rows).to_csv(out, mode="a", header=not out.exists(), index=False)
            first = task["readouts"][0]
            mean = np.mean([r[f"{first}_hz"] for r in rows])
            remaining = (time.time() - t0) / i * (len(todo) - i) / 60
            print(
                f"[{i}/{len(todo)}] {task['experiment']} {task['mode']}={task['level']:g} "
                f"{task['stim_hz']:g} Hz -> {first} = {mean:.1f} Hz ({seconds:.0f} s, faltam ~{remaining:.0f} min)",
                flush=True,
            )
    print(f"Concluído em {(time.time() - t0) / 60:.1f} min.")


if __name__ == "__main__":
    main()
