import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from synapsting.connectome import load_connectome
from synapsting.neurons import MN9, load_sets
from synapsting.perturbations import perturbation
from synapsting.simulator import LIFParams, simulate

INHIBITORY = ("gaba", "glutamate", "inhibitory_unknown")


def inputs_to(con, target):
    pre = con.pre_of_edges()
    mask = con.indices == target
    return pre[mask], con.weights[mask]


def main():
    ap = argparse.ArgumentParser(description="Entrada excitatória e inibitória no MN9 com e sem agonismo tônico.")
    ap.add_argument("--trials", type=int, default=5)
    ap.add_argument("--rho", type=float, default=1.0)
    ap.add_argument("--saida", default="resultados/final/analise/inibicao.csv")
    a = ap.parse_args()
    con = load_connectome("data", "783")
    sets = {k: con.idx(v) for k, v in load_sets().items()}
    mn9 = con.idx([MN9])[0]
    pre, w = inputs_to(con, mn9)
    inhibitory = np.isin(con.nt, INHIBITORY)
    p = LIFParams()
    _, bias = perturbation(con, "B", a.rho, p)
    rows = []
    for stim_name in ("water", "sugar"):
        for label, b in (("controle", None), (f"Modo B rho={a.rho:g}", bias)):
            counts = simulate(con, sets[stim_name], 200, n_trials=a.trials, params=p, bias_mv=b, seed=31)
            rate = counts.mean(0) / (p.t_run / 1000.0)
            drive = rate[pre] * w * p.w_syn
            rows.append(
                dict(
                    estimulo=stim_name,
                    condicao=label,
                    mn9_hz=rate[mn9],
                    entrada_excitatoria=drive[w > 0].sum(),
                    entrada_inibitoria=-drive[w < 0].sum(),
                    parceiros_inibitorios_ativos=int(((rate[pre] > 5) & (w < 0)).sum()),
                    taxa_media_inibitorios=rate[inhibitory].mean(),
                    taxa_media_colinergicos=rate[con.is_ach()].mean(),
                )
            )
            print(rows[-1], flush=True)
    Path(a.saida).parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).round(3).to_csv(a.saida, index=False)


if __name__ == "__main__":
    main()
