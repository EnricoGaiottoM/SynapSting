from __future__ import annotations

import argparse
import json
import re
import tomllib
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pypdf import PdfReader
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

AZUL = colors.HexColor("#1d3557")
CINZA = colors.HexColor("#5c677d")
LARANJA = colors.HexColor("#d17a22")
LARGURA = 17.8 * cm


def carregar_contato(caminho="configs/contato.json"):
    caminho = Path(caminho)
    if not caminho.exists():
        print(f"Aviso: {caminho} não existe; usando configs/contato.exemplo.json")
        caminho = Path("configs/contato.exemplo.json")
    contato = json.loads(caminho.read_text(encoding="utf-8"))
    faltando = [campo for campo, valor in contato.items() if str(valor).startswith("[")]
    if faltando:
        print(f"Aviso: ainda faltam dados em {caminho}: {', '.join(faltando)}")
    return contato


def br(x, casas=1) -> str:
    return f"{x:.{casas}f}".replace(".", ",")


def arred(x) -> int:
    return int(np.floor(x + 0.5))


def derivado(pasta, nome):
    """Arquivo gerado por scripts/analisar.py: fica em <pasta>/analise quando essa pasta existe."""
    p = Path(pasta) / "analise" / nome
    return p if p.exists() else Path(pasta) / nome


def ler(pasta, nome, tentativas=10):
    d = pd.read_csv(Path(pasta) / nome)
    return d[d.trial < tentativas] if "trial" in d else d


def circuito_limpeza(rel):
    return "Limpeza 250 Hz" if (rel.circuito == "Limpeza 250 Hz").any() else "Limpeza 200 Hz"


def calcular_numeros(pasta="resultados/preliminar") -> dict:
    pasta = Path(pasta)
    ajustes = pd.read_csv(derivado(pasta, "ajustes_modoA.csv"))
    linha = {round(a, 2): r for a, r in zip(ajustes.alpha, ajustes.itertuples())}
    rel = pd.read_csv(derivado(pasta, "modoA_vs_B.csv"))
    limpeza = circuito_limpeza(rel)

    def pct(circuito, condicao):
        base = rel.query("circuito == @circuito and condicao == 'controle'").media_hz
        x = rel.query("circuito == @circuito and condicao == @condicao").media_hz
        return arred(100 * x.iloc[0] / base.iloc[0]) if len(x) and len(base) else None

    def s50_com_ic(alfa):
        r = linha[alfa]
        return f"{br(r.s50)} Hz [{br(r.s50_lo)}–{br(r.s50_hi)}]"

    n = {
        "s50_controle": br(linha[0.0].s50),
        "s50_10": br(linha[0.1].s50),
        "s50_20": br(linha[0.2].s50),
        "s50_controle_ic": s50_com_ic(0.0),
        "s50_10_ic": s50_com_ic(0.1),
        "s50_20_ic": s50_com_ic(0.2),
        "aumento_10": str(arred(100 * (linha[0.1].s50 / linha[0.0].s50 - 1))),
        "alfa_abole": str(arred(100 * min(a for a, r in linha.items() if not np.isfinite(r.s50)))),
        "max_A20": str(pct("Alimentação 200 Hz", "Modo A α=0,2")),
        "max_B1": str(pct("Alimentação 200 Hz", "Modo B ρ=1")),
        "alim200_A10": str(pct("Alimentação 200 Hz", "Modo A α=0,1")),
        "limpeza_A10": str(pct(limpeza, "Modo A α=0,1")),
        "limpeza_B1": str(pct(limpeza, "Modo B ρ=1")),
        "agua_B1": str(pct("Água 200 Hz", "Modo B ρ=1")),
    }

    alim = ler(pasta, "alimentacao.csv")
    real = alim[(alim["mode"] == "A") & (alim.level.astype(float) == 0) & alim.stim_hz.isin([100, 200])]
    m = real.groupby("stim_hz").n_recruited_5hz.mean()
    n["recrut_real"] = f"{arred(m.min())} a {arred(m.max())}"
    if (pasta / "embaralhado.csv").exists():
        emb = ler(pasta, "embaralhado.csv")
        emb = emb[emb.level.astype(float) == 0] if "level" in emb else emb
        m = emb.groupby("stim_hz").n_recruited_5hz.mean()
        n["recrut_embaralhado"] = f"{arred(m.min())} a {arred(m.max())}"

    if derivado(pasta, "gargalos.csv").exists():
        g = pd.read_csv(derivado(pasta, "gargalos.csv"))
        g = g[g.flywire_id.astype(str) != "baseline"].sort_values("drop_pct", ascending=False).iloc[0]
        n["gargalo_max"], n["gargalo_tipo"] = str(arred(g.drop_pct)), str(g.cell_type)

    val = Path("resultados/validacao.json")
    if val.exists():
        v = json.loads(val.read_text())
        n.update(r_validacao=br(v["r"], 3), mn9_nosso=br(v["mn9_nosso"]), mn9_original=br(v["mn9_original"]))

    colunas = {
        "Modo A α=0,1": "Bloqueio α = 0,10",
        "Modo A α=0,15": "Bloqueio α = 0,15",
        "Modo A α=0,2": "Bloqueio α = 0,20",
        "Modo B ρ=0,5": "Agonista ρ = 0,5 Hz",
        "Modo B ρ=1": "Agonista ρ = 1 Hz",
    }
    tabela = [["Circuito (estímulo)"] + list(colunas.values())]
    for circuito in ["Alimentação 100 Hz", "Alimentação 200 Hz", "Água 200 Hz", limpeza]:
        celulas = [pct(circuito, c) for c in colunas]
        tabela.append([circuito] + ["—" if c is None else f"{c}%" for c in celulas])
    n["_tabela_vulnerabilidade"] = tabela
    return n


def preencher(texto: str, valores: dict) -> str:
    try:
        return texto.format_map(valores)
    except KeyError as erro:
        disponiveis = ", ".join(sorted(k for k in valores if not k.startswith("_")))
        raise SystemExit(
            f"O texto usa {{{erro.args[0]}}}, mas esse valor não existe.\n" f"Valores disponíveis: {disponiveis}"
        )


def desenhar_figura(pasta, saida):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8})
    pasta = Path(pasta)
    alim = ler(pasta, "alimentacao.csv")
    alim["level"] = alim.level.astype(float)
    rel = pd.read_csv(derivado(pasta, "modoA_vs_B.csv"))

    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.5), gridspec_kw={"width_ratios": [1.1, 1]})
    cores = {0.0: "#1b1b1b", 0.1: "#2a6f97", 0.2: "#61a5c2", 0.3: "#c9c9c9"}
    for alfa, cor in cores.items():
        m = alim[(alim["mode"] == "A") & (alim.level == alfa)].groupby("stim_hz").MN9_hz.agg(["mean", "std"])
        rotulo = "controle" if alfa == 0 else f"{arred(alfa * 100)}% de bloqueio"
        ax[0].errorbar(m.index, m["mean"], m["std"], color=cor, marker="o", ms=3, lw=1.4, capsize=2, label=rotulo)
    ax[0].set(xlabel="Estímulo de açúcar (Hz nos neurônios gustativos)", ylabel="Neurônio motor MN9 (Hz)")
    ax[0].set_title("A. Bloqueio colinérgico desloca a curva", loc="left", fontsize=8.5, fontweight="bold")
    ax[0].legend(frameon=False, fontsize=7)

    circuitos = [
        ("Alimentação 100 Hz", "Açúcar\nmoderado"),
        ("Alimentação 200 Hz", "Açúcar\nforte"),
        (circuito_limpeza(rel), "Limpeza\ndas antenas"),
    ]
    condicoes = [
        ("Modo A α=0,1", "Bloqueio 10%", "#2a6f97"),
        ("Modo A α=0,2", "Bloqueio 20%", "#61a5c2"),
        ("Modo B ρ=1", "Agonista tônico", "#d17a22"),
    ]
    x = np.arange(len(circuitos))
    for i, (cond, rotulo, cor) in enumerate(condicoes):
        valores = []
        for circ, _ in circuitos:
            base = rel.query("circuito == @circ and condicao == 'controle'").media_hz.iloc[0]
            v = rel.query("circuito == @circ and condicao == @cond").media_hz
            valores.append(100 * v.iloc[0] / base if len(v) else np.nan)
        ax[1].bar(x + (i - 1) * 0.26, valores, 0.26, color=cor, label=rotulo)
    ax[1].axhline(100, color="k", lw=0.7, ls="--")
    ax[1].set_xticks(x, [c[1] for c in circuitos])
    ax[1].set(ylabel="% da resposta do controle", ylim=(0, 128), yticks=[0, 25, 50, 75, 100])
    ax[1].set_title("B. Cada mecanismo deixa uma assinatura", loc="left", fontsize=8.5, fontweight="bold")
    ax[1].legend(frameon=False, fontsize=6.8, loc="upper center", ncol=3, columnspacing=0.8, handlelength=1.2)
    for a in ax:
        a.spines[["top", "right"]].set_visible(False)
    Path(saida).parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(saida, dpi=300)
    plt.close()


def registrar_fontes():
    pasta = Path(matplotlib.get_data_path()) / "fonts" / "ttf"
    for nome, arquivo in [
        ("Texto", "DejaVuSans.ttf"),
        ("Texto-Negrito", "DejaVuSans-Bold.ttf"),
        ("Texto-Italico", "DejaVuSans-Oblique.ttf"),
    ]:
        pdfmetrics.registerFont(TTFont(nome, str(pasta / arquivo)))
    pdfmetrics.registerFontFamily(
        "Texto", normal="Texto", bold="Texto-Negrito", italic="Texto-Italico", boldItalic="Texto-Negrito"
    )


def estilo(tamanho=8.6, entrelinha=11.6, fonte="Texto", cor=colors.black, **extra):
    return ParagraphStyle(
        f"e{tamanho}{fonte}{len(extra)}", fontName=fonte, fontSize=tamanho, leading=entrelinha, textColor=cor, **extra
    )


E = {}


def criar_estilos():
    E.update(
        titulo=estilo(19, 22, "Texto-Negrito", AZUL),
        subtitulo=estilo(9.5, 12.5, cor=CINZA),
        secao=estilo(9.6, 12, "Texto-Negrito", AZUL, spaceBefore=5, spaceAfter=1.5),
        texto=estilo(),
        item=estilo(leftIndent=10, bulletIndent=0),
        pequeno=estilo(7.2, 9, cor=CINZA),
        legenda=estilo(7.4, 9.2, "Texto-Italico", CINZA),
        celula=estilo(7.6, 9.4),
        cabecalho_tabela=estilo(7.6, 9.4, "Texto-Negrito", AZUL),
    )


def bloco_secao(b, v):
    return [Paragraph(preencher(b["texto"], v), E["secao"])]


def bloco_paragrafo(b, v):
    return [Paragraph(preencher(b["texto"], v), E["texto"])]


def bloco_lista(b, v):
    return [Paragraph(preencher(item, v), E["item"], bulletText="•") for item in b["itens"]]


def bloco_lista_numerada(b, v):
    return [Paragraph(preencher(item, v), E["item"], bulletText=f"{i}.") for i, item in enumerate(b["itens"], 1)]


def bloco_figura(b, v):
    largura, altura = ImageReader(v["_figura"]).getSize()
    pecas = [Spacer(1, 3), Image(v["_figura"], width=LARGURA, height=LARGURA * altura / largura)]
    if "legenda" in b:
        pecas.append(Paragraph(preencher(b["legenda"], v), E["legenda"]))
    return pecas


def _tabela(linhas, larguras=None):
    dados = [
        [Paragraph(str(c), E["cabecalho_tabela"] if i == 0 else E["celula"]) for c in linha]
        for i, linha in enumerate(linhas)
    ]
    t = Table(dados, colWidths=larguras or [LARGURA / len(linhas[0])] * len(linhas[0]))
    t.setStyle(
        TableStyle(
            [
                ("LINEBELOW", (0, 0), (-1, 0), 0.6, AZUL),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f4f7")]),
                ("TOPPADDING", (0, 0), (-1, -1), 2),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ]
        )
    )
    return t


def bloco_tabela(b, v):
    linhas = [[preencher(c, v) for c in linha] for linha in b["linhas"]]
    return [Spacer(1, 2), _tabela(linhas), Spacer(1, 2)]


def bloco_tabela_dados(b, v):
    linhas = v[b["dados"]]
    larguras = [4.2 * cm] + [(LARGURA - 4.2 * cm) / (len(linhas[0]) - 1)] * (len(linhas[0]) - 1)
    return [Spacer(1, 2), _tabela(linhas, larguras), Spacer(1, 2)]


def bloco_caixa(b, v):
    dentro = [Paragraph(preencher(b["titulo"], v), E["texto"])]
    dentro += bloco_lista({"itens": b.get("itens", [])}, v)
    if "nota" in b:
        dentro.append(Paragraph(preencher(b["nota"], v), E["texto"]))
    caixa = Table([[dentro]], colWidths=[LARGURA])
    caixa.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fff4e8")),
                ("BOX", (0, 0), (-1, -1), 0.8, LARANJA),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    return [Spacer(1, 5), caixa, Spacer(1, 3)]


def bloco_quebra_pagina(b, v):
    return [PageBreak()]


TIPOS = {
    "secao": bloco_secao,
    "paragrafo": bloco_paragrafo,
    "lista": bloco_lista,
    "lista_numerada": bloco_lista_numerada,
    "figura": bloco_figura,
    "tabela": bloco_tabela,
    "tabela_dados": bloco_tabela_dados,
    "caixa": bloco_caixa,
    "quebra_pagina": bloco_quebra_pagina,
}


def montar_pdf(cfg: dict, valores: dict, saida):
    if not E:
        registrar_fontes()
        criar_estilos()
    doc_cfg = cfg["documento"]
    historia = [
        Paragraph(preencher(doc_cfg["titulo"], valores), E["titulo"]),
        Spacer(1, 2),
        Paragraph(preencher(doc_cfg["subtitulo"], valores), E["subtitulo"]),
        Spacer(1, 3),
        Paragraph(preencher(doc_cfg["autoria"], valores), E["pequeno"]),
        Spacer(1, 4),
    ]
    for b in cfg.get("bloco", []):
        if b["tipo"] not in TIPOS:
            raise SystemExit(f"Tipo de bloco desconhecido: {b['tipo']}. Tipos válidos: {', '.join(TIPOS)}")
        historia += TIPOS[b["tipo"]](b, valores)
    historia += [Spacer(1, 4)] + [Paragraph(preencher(r, valores), E["pequeno"]) for r in doc_cfg.get("rodape", [])]
    Path(saida).parent.mkdir(parents=True, exist_ok=True)
    SimpleDocTemplate(
        str(saida),
        pagesize=A4,
        leftMargin=1.6 * cm,
        rightMargin=1.6 * cm,
        topMargin=1.3 * cm,
        bottomMargin=1.1 * cm,
        title=preencher(doc_cfg["titulo"], valores),
        author=valores.get("aluno", ""),
    ).build(historia)


def conferir(pdf, max_paginas: int) -> list[str]:
    leitor = PdfReader(str(pdf))
    texto = " ".join(p.extract_text() or "" for p in leitor.pages)
    problemas = []
    if len(leitor.pages) > max_paginas:
        problemas.append(f"tem {len(leitor.pages)} páginas; o limite é {max_paginas}")
    campos = sorted(set(re.findall(r"\[[^\]\d]{3,}\]", texto)))
    if campos:
        problemas.append(f"campos ainda por preencher: {', '.join(campos)}")
    return problemas


def gerar(config_toml, pasta_resultados="resultados/preliminar"):
    cfg = tomllib.loads(Path(config_toml).read_text(encoding="utf-8"))
    figura = derivado(pasta_resultados, "modoA_vs_B.csv").parent / "fig_resumo.png"
    desenhar_figura(pasta_resultados, figura)
    valores = {**carregar_contato(), **calcular_numeros(pasta_resultados), "_figura": str(figura)}
    saida = Path(cfg["documento"]["arquivo"])
    montar_pdf(cfg, valores, saida)
    problemas = conferir(saida, cfg["documento"].get("max_paginas", 99))
    paginas = len(PdfReader(str(saida)).pages)
    print(f"{saida}: {paginas} página(s)" + ("" if not problemas else " | ATENÇÃO: " + "; ".join(problemas)))
    return problemas


def main():
    ap = argparse.ArgumentParser(description="Gera os resumos em PDF do SynapSting.")
    ap.add_argument("configs", nargs="*", default=["configs/resumo_1pagina.toml", "configs/resumo_tecnico.toml"])
    ap.add_argument("--resultados", default="resultados/preliminar")
    a = ap.parse_args()
    for c in a.configs:
        gerar(c, a.resultados)


if __name__ == "__main__":
    main()
