"""Repete, com sementes novas, os neurônios que mais reduziram o MN9 na triagem e testa o par silenciado junto.

Uma triagem de 40 neurônios gera falsos positivos por acaso. Os candidatos só contam como gargalos se a queda
se repetir numa rodada independente, com controle próprio de 10 tentativas.
"""

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from synapsting.connectome import load_connectome
from synapsting.neurons import MN9, load_sets
from synapsting.simulator import simulate


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--triagem", default="resultados/final/analise/gargalos.csv")
    ap.add_argument("--top", type=int, default=3)
    ap.add_argument("--trials", type=int, default=10)
    ap.add_argument("--rate", type=float, default=100)
    ap.add_argument("--extra", type=int, nargs="*", default=[720575940627099338],
                    help="neurônios testados fora da triagem (padrão: a entrada colinérgica com mais sinapses no MN9)")
    ap.add_argument("--saida", default="resultados/final/gargalos/confirmacao.csv")
    a = ap.parse_args()
    con = load_connectome("data", "783")
    sugar, mn9 = con.idx(load_sets()["sugar"]), con.idx([MN9])[0]
    screen = pd.read_csv(a.triagem)
    screen = screen[screen.flywire_id.astype(str) != "baseline"].sort_values("drop_pct", ascending=False)
    top = screen.head(a.top)
    tests = [("controle", [])]
    tests += [(f"{r.cell_type} {r.flywire_id}", [int(r.flywire_id)]) for r in top.itertuples()]
    pair = screen[screen.cell_type == top.cell_type.iloc[0]]
    if len(pair) > 1:
        tests.append((f"par {top.cell_type.iloc[0]}", [int(x) for x in pair.flywire_id]))
    seeds = [500 + k for k in range(len(tests))]
    for j, fid in enumerate(a.extra, 1):
        tests.append((f"extra {fid}", [fid]))
        seeds.append(600 + j)
    rows = []
    for (label, ids), seed in zip(tests, seeds):
        silence = con.idx(ids).tolist() if ids else None
        counts = simulate(con, sugar, a.rate, n_trials=a.trials, silence=silence, seed=seed)
        per_trial = counts[:, mn9]
        rows.append(dict(teste=label, ids=" ".join(map(str, ids)), mn9_hz=per_trial.mean(), dp=per_trial.std(ddof=1)))
        print(rows[-1], flush=True)
    d = pd.DataFrame(rows)
    base = d.mn9_hz.iloc[0]
    d["queda_pct"] = 100 * (1 - d.mn9_hz / base)
    d["ep_diferenca_pct"] = 100 * np.sqrt(d.dp**2 / a.trials + d.dp.iloc[0] ** 2 / a.trials) / base
    Path(a.saida).parent.mkdir(parents=True, exist_ok=True)
    d.round(2).to_csv(a.saida, index=False)
    print(d.round(1).to_string(index=False))


if __name__ == "__main__":
    main()
