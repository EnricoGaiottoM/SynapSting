import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from synapsting.connectome import load_connectome
from synapsting.neurons import MN9, load_sets
from synapsting.simulator import simulate


def main():
    reference = sys.argv[1] if len(sys.argv) > 1 else "data/shiu_sugarR_200Hz.parquet"
    con = load_connectome("data", "630")
    sugar, mn9 = con.idx(load_sets()["sugar"]), con.id2idx[MN9]
    ref = np.zeros(con.N)
    for fid, rate in (pd.read_parquet(reference).groupby("flywire_id").size() / 30).items():
        ref[con.id2idx[fid]] = rate
    ours = simulate(con, sugar, 200, n_trials=6, seed=2).mean(0)
    active = (ours > 0) | (ref > 0)
    r = float(np.corrcoef(ours[active], ref[active])[0, 1])
    result = {
        "r": round(r, 4),
        "razao_total": round(float(ours.sum() / ref.sum()), 3),
        "mn9_nosso": round(float(ours[mn9]), 1),
        "mn9_original": round(float(ref[mn9]), 1),
    }
    print(f"Correlação entre neurônios ativos: r = {r:.4f}")
    print(f"Atividade total (nosso / original): {result['razao_total']}")
    print(f"MN9: {result['mn9_nosso']} Hz (nosso) | {result['mn9_original']} Hz (original)")
    Path("resultados").mkdir(exist_ok=True)
    Path("resultados/validacao.json").write_text(json.dumps(result))


if __name__ == "__main__":
    main()
