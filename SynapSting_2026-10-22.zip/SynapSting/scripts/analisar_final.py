import sys
from pathlib import Path

import numpy as np
import pandas as pd

from synapsting.analysis import bootstrap_hill

READOUT = {"alimentacao": "MN9_hz", "agua": "MN9_hz", "limpeza": "aDN1_hz", "embaralhado": "MN9_hz"}
TRIALS = 10


def read(folder, name):
    f = folder / f"{name}.csv"
    if not f.exists():
        return None
    d = pd.read_csv(f)
    d["level"] = d.level.astype(float)
    return d[d.trial < TRIALS]


def summary(d, name):
    col = READOUT[name]
    keys = ["mode", "level", "stim_hz"] + (["rep"] if name == "embaralhado" else [])
    s = d.groupby(keys).agg(
        media=(col, "mean"), dp=(col, "std"), n=(col, "size"), recrutados=("n_recruited_5hz", "mean")
    )
    s.insert(0, "experimento", name)
    return s.reset_index()


def fits(d, name, n_boot):
    col = READOUT[name]
    rows = []
    for (mode, level), g in d.groupby(["mode", "level"]):
        f = bootstrap_hill(g, resp_col=col, n_boot=n_boot, seed=7)
        rows.append(dict(experimento=name, mode=mode, level=level, **{k: f[k] for k in ("s50", "s50_lo", "s50_hi", "rmax", "n", "frac_finite")}))
    return pd.DataFrame(rows)


def relative(sumtab):
    rows = []
    for (name, stim), g in sumtab[sumtab.experimento != "embaralhado"].groupby(["experimento", "stim_hz"]):
        ctrl = g[(g["mode"] == "A") & (g.level == 0)].media
        if not len(ctrl) or ctrl.iloc[0] <= 0:
            continue
        for r in g.itertuples():
            rows.append(dict(experimento=name, stim_hz=stim, mode=r.mode, level=r.level, pct_controle=100 * r.media / ctrl.iloc[0]))
    return pd.DataFrame(rows)


def main():
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else "resultados/final")
    n_boot = int(sys.argv[2]) if len(sys.argv) > 2 else 500
    data = {n: read(folder, n) for n in READOUT}
    out = folder / "analise"
    out.mkdir(exist_ok=True)
    sums = pd.concat([summary(d, n) for n, d in data.items() if d is not None], ignore_index=True)
    sums.round(3).to_csv(out / "resumo_condicoes.csv", index=False)
    fit_tab = pd.concat([fits(d, n, n_boot) for n, d in data.items() if d is not None and n != "embaralhado"], ignore_index=True)
    fit_tab.round(4).to_csv(out / "ajustes_hill.csv", index=False)
    rel = relative(sums)
    rel.round(2).to_csv(out / "relativo_controle.csv", index=False)
    print(fit_tab.round(2).to_string(index=False))
    print()
    print(rel[rel.stim_hz.isin([100, 200, 250])].round(1).to_string(index=False))
    if data["embaralhado"] is not None:
        e = sums[sums.experimento == "embaralhado"].groupby(["level", "stim_hz"])[["media", "recrutados"]].agg(["mean", "min", "max"])
        print("\nEmbaralhado (3 sementes):")
        print(e.round(1).to_string())


if __name__ == "__main__":
    main()
