import argparse
import hashlib
import sys
import time
import urllib.request
from pathlib import Path

SHIU = "https://raw.githubusercontent.com/philshiu/Drosophila_brain_model/91bdd1e7dcf193f3e7ca5a8933497fcef63b7960/"
FLYWIRE = (
    "https://raw.githubusercontent.com/flyconnectome/flywire_annotations/8587524c1748ce5ef2080822a2fc890fc03bf597/"
)
FILES = {
    "Connectivity_783.parquet": (
        SHIU + "Connectivity_783.parquet",
        "efeb23fb99098e9c390f6869969b2a121a2ee92c833cfc45ecb2c1d8e1af0347",
        True,
    ),
    "Completeness_783.csv": (
        SHIU + "Completeness_783.csv",
        "bbb847a4cc2caaa7a16349722d220c087317b946d148d4d592d94d250617a311",
        True,
    ),
    "flywire_annotations_783.tsv": (
        FLYWIRE + "supplemental_files/Supplemental_file1_neuron_annotations.tsv",
        "9a4f8b2f843196074431ebd7cd883536afa1be86c8a4ce90970441e8be81d1be",
        True,
    ),
    "Connectivity_630.parquet": (
        SHIU + "2023_03_23_connectivity_630_final.parquet",
        "94db8c650533bc36ffa3223f2e62325d5648b8d6bd31c3a4e1c804628c7557b3",
        False,
    ),
    "Completeness_630.csv": (
        SHIU + "2023_03_23_completeness_630_final.csv",
        "e6b71e17671a9bdb05f55e4bc6774640a1418cb7a05125e0fc994ad40f9bfdfb",
        False,
    ),
    "shiu_sugarR_200Hz.parquet": (
        SHIU + "results/example/sugarR.parquet",
        "83921d50089d966785e402d6c0e3be5ab3eba5beb680410a09c557b0f22dcc28",
        False,
    ),
}


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(1 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def download(url, dest, tries=3):
    tmp = dest.with_suffix(dest.suffix + ".part")
    for attempt in range(1, tries + 1):
        try:
            with urllib.request.urlopen(url, timeout=60) as response, open(tmp, "wb") as f:
                received = 0
                while chunk := response.read(1 << 20):
                    f.write(chunk)
                    received += len(chunk)
                    print(f"\r  {dest.name}: {received / 1e6:.1f} MB", end="", flush=True)
            print()
            tmp.replace(dest)
            return
        except OSError as error:
            print(f"\n  tentativa {attempt} falhou: {error}")
            time.sleep(3 * attempt)
    sys.exit(f"Não foi possível baixar {url}")


def main():
    ap = argparse.ArgumentParser(description="Baixa os dados do conectoma em versões fixas e confere o SHA-256.")
    ap.add_argument("--all", action="store_true", help="inclui a versão 630 e o arquivo de validação")
    ap.add_argument("--verify", action="store_true", help="só confere os arquivos existentes")
    ap.add_argument("--dir", default="data")
    a = ap.parse_args()
    folder = Path(a.dir)
    folder.mkdir(exist_ok=True)
    ok = True
    for name, (url, digest, required) in FILES.items():
        if not (required or a.all):
            continue
        dest = folder / name
        if not dest.exists():
            if a.verify:
                print(f"[FALTA] {name}")
                ok = False
                continue
            download(url, dest)
        good = sha256(dest) == digest
        print(f"[{'OK' if good else 'ERRO'}] {name}")
        ok &= good
    print("Tudo certo." if ok else "Há problemas: apague o arquivo com ERRO e rode de novo.")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
