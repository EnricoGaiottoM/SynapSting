# Diário de bordo digital

Registro cronológico do projeto, complementar ao diário de bordo da FEBRACE. Uma entrada por dia de trabalho,
da mais antiga para a mais recente. Cada entrada cita os commits do dia (`git log --oneline --since=midnight`).

## Modelo de entrada

```
### AAAA-MM-DD — título curto
Horas trabalhadas:
Objetivo do dia:
O que foi feito:
Resultados (com números e unidades):
Problemas e soluções:
Decisões e justificativas:
Próximo passo:
Commits:
```

## Registros
