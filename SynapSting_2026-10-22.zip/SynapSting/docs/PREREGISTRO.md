# Pré-registro — SynapSting

**Data do registro:** {data} (a tag `prereg-v1` no GitHub e o registro no OSF são o carimbo de data)
**Autor:** {aluno} · **Orientador:** {orientador} · **Laboratório:** Departamento de Entomologia e Acarologia, ESALQ/USP

> Este documento é publicado **antes** de qualquer mosca receber imidacloprido.
> Depois de publicado, não é editado. Correções entram num adendo datado, no fim do arquivo.

## 1. Pergunta

Um modelo do cérebro inteiro de *Drosophila melanogaster*, construído a partir do conectoma FlyWire, prevê como e quanto
o imidacloprido altera o reflexo de extensão da probóscide (PER) e a limpeza das antenas, e qual mecanismo explica o
efeito: bloqueio da transmissão colinérgica (Modo A) ou agonismo tônico (Modo B)?

## 2. Previsões do modelo

Números da grade final (`resultados/final`, configuração `configs/final.json`). Modo A: 10 simulações de 1 s por condição;
Modo B: 4 de 0,5 s. Intervalos de 95% por bootstrap.

α = fração das sinapses colinérgicas bloqueadas (Modo A). ρ = taxa de ativação tônica dos receptores (Modo B).
Os valores de α e ρ não têm equivalência direta com concentração; o modelo prevê **direção e forma** dos efeitos.

| Previsão | Medida no modelo | Valores do modelo | Medida nas moscas |
|---|---|---|---|
| **H1.** O imidacloprido eleva o limiar do PER à sacarose | S50 do MN9 (controle: 75,1 Hz, IC 72,1–78,6) | +15% (α = 0,05); +43% (α = 0,1; IC 102,3–115,4 Hz); +82% (α = 0,15); +121% (α = 0,2). Modo B: +77% (ρ = 0,5 Hz); +84% (ρ = 1 Hz) | EC50 de sacarose maior no grupo tratado |
| Faixa estreita entre efeito e colapso | MN9 com o estímulo mais forte | Acima de 70% do controle até α = 0,15; 46% com α = 0,2; 19% com α = 0,25; ~2% com α = 0,3 | Concentrações altas demais abolem o PER em vez de deslocar a curva (piloto de sobrevivência e calibração) |
| **H3.** Alimentação perde sensibilidade; limpeza perde intensidade | Aumento do S50 e resposta ao estímulo mais forte (alimentação a 200 Hz; limpeza a 250 Hz) | α = 0,1: alimentação +43% no limiar e 86% da resposta máxima; limpeza +11% no limiar e 62% da resposta máxima. α = 0,2: 46% contra 29%. Modo B: limpeza 21% (ρ = 0,5) e 8% (ρ = 1); alimentação 98% e 102% | Queda relativa da limpeza das antenas maior que a queda relativa do PER a 1.000 mM, na mesma concentração |
| **H4.** Só o bloqueio reduz a resposta máxima | MN9 com açúcar a 200 Hz, em % do controle | Modo A: 86% (α = 0,1), 74% (α = 0,15), 46% (α = 0,2). Modo B: 98% a 102% em todo ρ testado | PER à sacarose de 1.000 mM: queda favorece o Modo A; manutenção favorece o Modo B |
| **H4b.** Nenhum mecanismo aumenta a resposta à água | MN9 com água a 200 e 250 Hz | Controle: 31,3 e 49,5 Hz. Modo A (α = 0,1): 12% e 32% do controle. Modo B: 3% a 26% do controle | Resposta à água no grupo tratado ≤ veículo |
| **H5.** Moscas sem tratamento têm curva sigmoide | Coeficiente de Hill do controle | 3,9 | Ajuste logístico com inclinação positiva |
| **H2** (só no modelo, já testada) | MN9 e recrutamento no conectoma embaralhado | MN9 = 0 Hz em todas as condições; 24 e 67 neurônios recrutados a 100 e 200 Hz, contra 235 e 301 no cérebro real | — |

Resultados do modelo que **não** serão testados nas moscas nesta etapa (exploratórios): silenciar o par de neurônios
CB0553 reduz o MN9 em 72% (`resultados/final/gargalos/confirmacao.csv`); no Modo B, o MN9 silencia com água porque a
entrada excitatória cai, e não porque a inibição direta aumenta (`resultados/final/analise/inibicao.csv`).

## 3. Desenho experimental

- **Moscas:** fêmeas de *D. melanogaster* de linhagem selvagem, da mesma criação, idade e horário de teste.
- **Grupos:** veículo e 3 concentrações de imidacloprido na dieta, definidas no piloto de sobrevivência
  (mortalidade abaixo de 10% em 24 h). As concentrações e o tempo de exposição são registrados em adendo
  **antes** do experimento principal.
- **Ensaio de PER:** jejum de 24 h com água; gelo por no máximo 5 min; fixação em ponteira; sede saciada com água;
  sacarose a 1, 3, 10, 30, 100, 300 e 1.000 mM, em ordem crescente, com água entre as concentrações e controle positivo
  no fim. Resposta = extensão completa da probóscide em até 2 s.
- **Medidas secundárias:** PER à água e limpeza das antenas induzida por poeira.
- **Cegamento:** frascos codificados por pessoa externa (`laboratorio/cegamento.py`); ordem de teste sorteada; a chave
  fica com o orientador até o fim da análise.
- **Pontuação:** PER-bot se o kappa de Cohen contra avaliador cego for ≥ 0,8 em pelo menos 200 eventos; caso contrário,
  pontuação manual e cega dos vídeos.

## 4. Tamanho da amostra (regra definida agora)

- **45 moscas por grupo.** Na simulação de poder (`laboratorio/poder.py`, 300 experimentos por cenário), esse número
  detecta uma EC50 duas vezes maior com poder de 81% a 94% (teste unilateral, α = 0,05), conforme a variação entre
  moscas seja de 0,4 ou 0,25 unidade logarítmica.
- Se a calibração com moscas sem tratamento mostrar desvio-padrão entre moscas **maior que 0,4**, o número sobe para
  **60 por grupo**.
- Se o tempo de laboratório não bastar, o grupo de concentração intermediária é o primeiro a ser cortado.
- Limite declarado: efeitos de 1,5 vez na EC50 têm poder abaixo de 60% com 45 moscas.

## 5. Exclusões (definidas agora)

- Mosca que não responde à sacarose mais concentrada.
- Mosca que morre ou se solta durante o ensaio.
- Nenhuma outra exclusão. O número de moscas excluídas em cada grupo é relatado.

## 6. Análise (definida agora)

- **Primária (H1):** modelo logístico da resposta em função de log10(sacarose) e do grupo, com a mosca como unidade de
  agrupamento (GEE, correlação permutável). Teste **unilateral**, α = 0,05: o grupo de maior concentração precisa de
  mais açúcar que o veículo. Tamanho do efeito: razão de EC50 tratado/veículo, com IC 95% por bootstrap de moscas.
- **Secundárias:** tendência entre as doses; demais concentrações contra o veículo, com correção de Holm; modelo
  logístico misto com a mosca como efeito aleatório.
- **H3:** queda relativa = 1 − (proporção que responde no tratado ÷ proporção no veículo), calculada para a limpeza
  das antenas e para o PER à sacarose de 1.000 mM, no grupo de maior concentração. H3 é apoiada se a queda relativa da
  limpeza for maior, com IC 95% da diferença (bootstrap de moscas, 2.000 reamostragens) inteiramente acima de zero.
- **H4:** proporção de PER à sacarose de 1.000 mM no grupo de maior concentração contra o veículo.
  *Queda* (favorece o Modo A): proporção menor no tratado, teste exato de Fisher unilateral, α = 0,05.
  *Manutenção* (favorece o Modo B): IC 95% da diferença (tratado − veículo) inteiramente acima de −10 pontos percentuais.
  Nenhum dos dois: **inconclusivo**, e assim será relatado.
- **H4b:** resposta à água no grupo tratado ≤ veículo (apoiada se o IC 95% da diferença tratado − veículo não ficar
  inteiramente acima de zero).
- **H5:** curva logística das moscas sem tratamento com inclinação positiva e IC 95% que não inclui zero.

## 7. O que muda a conclusão

- Resultados contrários às previsões serão publicados como refutação, com a análise de onde o modelo falha.
- Nenhuma análise fora desta lista será apresentada como confirmatória. Análises novas serão chamadas de exploratórias.

## Adendos

(nenhum)
