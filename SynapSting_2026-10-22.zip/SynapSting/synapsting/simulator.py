from dataclasses import dataclass

import numpy as np


@dataclass
class LIFParams:
    dt: float = 0.1
    t_run: float = 1000.0
    v0: float = -52.0
    v_rst: float = -52.0
    v_th: float = -45.0
    t_mbr: float = 20.0
    tau: float = 5.0
    t_rfc: float = 2.2
    t_dly: float = 1.8
    w_syn: float = 0.275
    f_poi: float = 250.0


def simulate(
    con, stim, rate_hz, n_trials=10, params=None, weight_scale=None, bias_mv=None, silence=None, seed=0, prune_every=20
):
    p = params or LIFParams()
    rng = np.random.default_rng(seed)
    n, k = con.N, n_trials
    n_steps = int(round(p.t_run / p.dt))
    delay = max(1, int(round(p.t_dly / p.dt)))
    rfc_steps = int(round(p.t_rfc / p.dt))
    pm = np.exp(-p.dt / p.t_mbr)
    pg = np.exp(-p.dt / p.tau)
    q = p.tau / (p.tau - p.t_mbr) * (pg - pm)

    w_eff = con.weights * np.float32(p.w_syn)
    if weight_scale is not None:
        w_eff = w_eff * weight_scale.astype(np.float32)
    if silence is not None:
        w_eff = w_eff.copy()
        for i in np.atleast_1d(silence):
            w_eff[con.indptr[i] : con.indptr[i + 1]] = 0.0
    indptr, indices = con.indptr, con.indices

    rest = np.tile(np.full(n, p.v0) if bias_mv is None else p.v0 + bias_mv, k)
    v = rest.copy()
    g = np.zeros(n * k)
    ref_until = np.zeros(n * k, dtype=np.int64)
    counts = np.zeros(n * k, dtype=np.int32)

    stim = np.asarray(stim, dtype=np.int64)
    stim_flat = (stim[None, :] + (np.arange(k, dtype=np.int64) * n)[:, None]).ravel()
    rfc_unit = np.full(n * k, rfc_steps, dtype=np.int64)
    rfc_unit[stim_flat] = 0
    p_input = rate_hz * p.dt / 1000.0
    kick = p.w_syn * p.f_poi

    always = np.unique(np.concatenate([stim_flat, np.flatnonzero(rest > p.v_th)]))
    is_always = np.zeros(n * k, dtype=bool)
    is_always[always] = True
    is_active = is_always.copy()
    active = always.copy()
    queue = [np.empty(0, dtype=np.int64) for _ in range(delay)]

    for t in range(n_steps):
        a = active
        free = a[ref_until[a] <= t]
        if free.size:
            vf, gf, rf = v[free], g[free], rest[free]
            v[free] = rf + (vf - rf) * pm + gf * q
            g[free] = gf * pg
        spikes = a[(v[a] > p.v_th) & (ref_until[a] <= t)]

        due = queue[t % delay]
        if due.size:
            src = due % n
            starts = indptr[src]
            lens = indptr[src + 1] - starts
            total = int(lens.sum())
            if total:
                pos = np.repeat(starts - (np.cumsum(lens) - lens), lens) + np.arange(total)
                tgt = indices[pos].astype(np.int64) + np.repeat(due - src, lens)
                ok = ref_until[tgt] <= t
                tgt = tgt[ok]
                np.add.at(g, tgt, w_eff[pos][ok])
                new = np.unique(tgt[~is_active[tgt]])
                if new.size:
                    is_active[new] = True
                    active = np.concatenate([active, new])

        if p_input > 0 and stim_flat.size:
            v[stim_flat[rng.random(stim_flat.size) < p_input]] += kick
        if spikes.size:
            v[spikes] = p.v_rst
            g[spikes] = 0.0
            ref_until[spikes] = t + rfc_unit[spikes]
            counts[spikes] += 1
        queue[t % delay] = spikes

        if t % prune_every == 0 and active.size > always.size:
            quiet = (
                (np.abs(v[active] - rest[active]) < 1e-4)
                & (np.abs(g[active]) < 1e-4)
                & (ref_until[active] <= t)
                & ~is_always[active]
            )
            if quiet.any():
                done = active[quiet]
                v[done] = rest[done]
                g[done] = 0.0
                is_active[done] = False
                active = active[~quiet]

    return counts.reshape(k, n)
