import json
from pathlib import Path

MN9 = 720575940660219265
MN9_PAIR = [720575940660219265, 720575940618238523]
ADN1 = 720575940616185531
ABN1 = 720575940630907434


def load_sets():
    return json.loads(Path(__file__).with_name("neuron_ids.json").read_text())
