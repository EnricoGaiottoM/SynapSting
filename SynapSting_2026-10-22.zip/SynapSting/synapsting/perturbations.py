import hashlib
from dataclasses import replace

import numpy as np

from .simulator import LIFParams


def perturbation(con, mode, level, params=None):
    p = params or LIFParams()
    if level == 0:
        return None, None
    if mode == "A":
        return np.where(con.is_ach()[con.pre_of_edges()], 1.0 - level, 1.0).astype(np.float32), None
    if mode == "B":
        return None, p.w_syn * con.ach_synapses_in() * level * (p.tau / 1000.0)
    raise ValueError(f"Modo desconhecido: {mode}")


def shuffle_connectome(con, seed=0):
    indices = con.indices.copy()
    np.random.default_rng(seed).shuffle(indices)
    return replace(con, indices=indices)


def stable_seed(*parts):
    return int(hashlib.sha256("|".join(map(str, parts)).encode()).hexdigest()[:8], 16)
