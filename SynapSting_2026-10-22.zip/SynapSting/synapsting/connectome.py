from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd


@dataclass
class Connectome:
    ids: np.ndarray
    indptr: np.ndarray
    indices: np.ndarray
    weights: np.ndarray
    nt: np.ndarray
    version: str = "783"
    id2idx: dict = field(default_factory=dict)

    @property
    def N(self):
        return len(self.ids)

    @property
    def n_edges(self):
        return len(self.indices)

    def idx(self, flywire_ids):
        return np.asarray([self.id2idx[int(f)] for f in flywire_ids if int(f) in self.id2idx], dtype=np.int64)

    def is_ach(self):
        return self.nt == "acetylcholine"

    def pre_of_edges(self):
        return np.repeat(np.arange(self.N, dtype=np.int32), np.diff(self.indptr))

    def ach_synapses_in(self):
        mask = self.is_ach()[self.pre_of_edges()]
        return np.bincount(self.indices[mask], weights=np.abs(self.weights[mask]), minlength=self.N)


def load_connectome(data_dir="data", version="783", annotations=None):
    data_dir = Path(data_dir)
    ids = pd.read_csv(data_dir / f"Completeness_{version}.csv", index_col=0).index.to_numpy(np.int64)
    n = len(ids)
    edges = pd.read_parquet(
        data_dir / f"Connectivity_{version}.parquet",
        columns=["Presynaptic_Index", "Postsynaptic_Index", "Excitatory x Connectivity"],
    )
    pre = edges["Presynaptic_Index"].to_numpy(np.int32)
    post = edges["Postsynaptic_Index"].to_numpy(np.int32)
    w = edges["Excitatory x Connectivity"].to_numpy(np.float32)
    order = np.argsort(pre, kind="stable")
    pre, post, w = pre[order], post[order], w[order]
    indptr = np.zeros(n + 1, dtype=np.int64)
    np.cumsum(np.bincount(pre, minlength=n), out=indptr[1:])

    nt = np.full(n, "unknown", dtype=object)
    ann_path = Path(annotations) if annotations else data_dir / "flywire_annotations_783.tsv"
    if ann_path.exists():
        ann = pd.read_csv(ann_path, sep="\t", usecols=["root_id", "top_nt"], low_memory=False)
        lookup = dict(zip(ann.root_id.astype(np.int64), ann.top_nt.fillna("unknown")))
        nt = np.array([lookup.get(int(i), "unknown") for i in ids], dtype=object)
    excitatory = np.zeros(n, dtype=bool)
    excitatory[pre[w > 0]] = True
    unknown = nt == "unknown"
    nt[unknown & excitatory] = "excitatory_unknown"
    nt[unknown & ~excitatory] = "inhibitory_unknown"

    con = Connectome(ids, indptr, post, w, nt.astype(str), version)
    con.id2idx = {int(f): i for i, f in enumerate(ids)}
    return con
