import os
import platform
import sys
import time
from pathlib import Path

from .connectome import load_connectome
from .neurons import MN9, load_sets
from .simulator import LIFParams, simulate

REQUIRED = ["Connectivity_783.parquet", "Completeness_783.csv", "flywire_annotations_783.tsv"]


def main():
    print(f"Python {sys.version.split()[0]} | {platform.system()} | {os.cpu_count()} núcleos")
    missing = [f for f in REQUIRED if not (Path("data") / f).exists()]
    if missing:
        sys.exit(f"Faltam dados: {', '.join(missing)}. Rode: python scripts/baixar_dados.py")
    t0 = time.time()
    con = load_connectome("data", "783")
    print(f"Conectoma: {con.N} neurônios, {con.n_edges} pares ({time.time() - t0:.1f} s)")
    sugar, mn9 = con.idx(load_sets()["sugar"]), con.idx([MN9])[0]
    t0 = time.time()
    rate = simulate(con, sugar, 200, n_trials=2, params=LIFParams(t_run=300), seed=1)[:, mn9].mean() / 0.3
    print(f"Açúcar a 200 Hz: MN9 = {rate:.0f} Hz ({time.time() - t0:.1f} s)")
    print("OK: instalação funcionando." if rate > 30 else "ERRO: resposta do MN9 abaixo do esperado.")


if __name__ == "__main__":
    main()
