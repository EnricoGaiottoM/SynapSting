# SynapSting

![testes](https://github.com/EnricoGaiottoM/SynapSting/actions/workflows/testes.yml/badge.svg)

**Um gêmeo digital do cérebro de *Drosophila melanogaster* para prever e testar os efeitos subletais do imidacloprido no comportamento.**

FEBRACE 2027 · Ciências Biológicas · Metodologia Científica

![Resultados da grade final](resultados/final/analise/fig_resumo.png)

## Resumo

Os neonicotinoides, como o imidacloprido, são a classe de inseticidas mais usada no mundo e, em doses que não matam, prejudicam a resposta de abelhas ao açúcar. Este projeto usa o modelo computacional do cérebro inteiro da mosca-da-fruta, construído a partir do conectoma FlyWire (138.639 neurônios; Shiu et al., *Nature*, 2024), para simular dois mecanismos de ação do inseticida e prever seu efeito no reflexo de alimentação. As previsões serão registradas publicamente e testadas em moscas reais com um instrumento de baixo custo. O objetivo é uma triagem rápida e barata dos efeitos neurológicos de inseticidas, antes de longos ensaios de laboratório.

## Pergunta e hipóteses

Um modelo do cérebro inteiro, construído a partir do conectoma, consegue prever como e quanto um neonicotinoide altera o comportamento, e distinguir qual mecanismo explica esse efeito?

| | Hipótese |
| --- | --- |
| H1 | O bloqueio colinérgico eleva o limiar do reflexo de extensão da probóscide |
| H2 | O efeito depende da fiação real do conectoma |
| H3 | Alimentação e limpeza das antenas têm vulnerabilidades diferentes |
| H4 | O bloqueio reduz a resposta ao estímulo mais forte; o agonismo tônico a preserva |
| H5 | Moscas sem tratamento reproduzem o formato da curva prevista |

## Método

1. **Modelo:** neurônios do tipo integra-e-dispara (LIF) ligados pelo conectoma FlyWire v783, com os parâmetros de Shiu et al. (2024).
2. **Mecanismos:** Modo A multiplica por (1 − α) as sinapses de neurônios colinérgicos (bloqueio); Modo B soma a cada neurônio uma despolarização proporcional às suas sinapses colinérgicas de entrada (agonismo tônico).
3. **Validação:** a implementação própria reproduz o modelo original (correlação de 0,999 entre neurônios).
4. **Controles:** conectoma com ligações embaralhadas e triagem de neurônios-gargalo.
5. **Experimento:** reflexo de extensão da probóscide em moscas, medido por um instrumento com Arduino e visão computacional, com cegamento e análise pré-registrada (`docs/PREREGISTRO.md`).

## Resultados do modelo (grade final)

179 combinações de condição e estímulo; 10 simulações de 1 s por ponto no Modo A e 4 de 0,5 s no Modo B
(`configs/final.json`, tabelas em `resultados/final/analise`).

| Hipótese | Resultado no modelo |
| --- | --- |
| H1 | Bloquear 10% da transmissão colinérgica eleva o limiar do reflexo de 75,1 para 107,6 Hz (+43%; IC 95% sem sobreposição com o controle); com 30% de bloqueio, a resposta praticamente desaparece. |
| H2 | No conectoma embaralhado (3 sementes), o MN9 não responde, e o açúcar recruta 24 e 67 neurônios, contra 235 e 301 no cérebro real. |
| H3 | Com 10% de bloqueio, a alimentação perde sensibilidade (limiar +43%, resposta máxima em 86%) e a limpeza das antenas perde intensidade (limiar +11%, resposta máxima em 62%). |
| H4 | Os dois mecanismos elevam o limiar (+43% a +121% no bloqueio; +77% a +84% no agonismo tônico), mas só o bloqueio reduz a resposta ao açúcar forte (46% do controle com 20% de bloqueio, contra 98% a 102%). |
| H4b | Nenhum mecanismo aumenta a resposta à água. |
| H5 | No modelo, a curva do controle tem coeficiente de Hill de 3,9; o teste é nas moscas. |

**Triagem de gargalos.** Silenciar um a um os 40 neurônios colinérgicos mais ativos reduz o MN9 em média 6%; o maior
efeito isolado é de 35% (tipo CB0553), menor que o do bloqueio difuso de 10% (43%). Os dois neurônios CB0553, um em cada
hemisfério, silenciados juntos, reduzem o MN9 em 72% (confirmado com sementes novas, `scripts/confirmar_gargalos.py`).

As previsões numéricas e os critérios de confirmação estão em [`docs/PREREGISTRO.md`](docs/PREREGISTRO.md).

## Reprodução

Requer Python 3.11 ou mais novo.

```bash
pip install -e ".[dev]"
python scripts/baixar_dados.py --all
python -m synapsting.check
python -m pytest
```

| Etapa | Comando |
| --- | --- |
| Validar contra o modelo original | `python scripts/validar.py` |
| Rodar a grade de simulações | `python scripts/rodar_grade.py configs/final.json --jobs 4` |
| Triagem de gargalos | `python scripts/gargalos.py --top 40 --trials 10` |
| Ajustar curvas com IC por bootstrap | `python scripts/analisar_final.py resultados/final` |
| Gerar figuras | `python scripts/analisar.py resultados/final` |
| Teste do mecanismo inibitório | `python scripts/inibicao.py --trials 4` |
| Simulação de poder do experimento | `python laboratorio/poder.py` |
| Gerar os resumos em PDF | `python scripts/resumos.py --resultados resultados/final` |

Os dados do conectoma são baixados de versões fixas dos repositórios originais e conferidos por SHA-256. A grade é retomada automaticamente se for interrompida.

## Estrutura

| Pasta | Conteúdo |
| --- | --- |
| `synapsting/` | Conectoma, simulador, mecanismos do inseticida e análise de curvas |
| `scripts/` | Comandos de cada etapa |
| `configs/` | Grades de simulação, textos dos resumos e modelo de contato |
| `resultados/` | Dados e figuras de cada rodada |
| `laboratorio/` | PER-bot (firmware e análise de vídeo), cegamento e estatística dos experimentos |
| `docs/` | Pré-registro e diário de bordo; os resumos em PDF são gerados localmente |
| `testes/` | Testes automáticos, executados a cada envio |

## Ética e segurança

Os experimentos com imidacloprido só ocorrem no laboratório parceiro (Departamento de Entomologia e Acarologia da ESALQ/USP, parceria em formalização), sob supervisão de cientista qualificado, com os formulários 2B e 3 da FEBRACE assinados e depois do pré-registro. *Drosophila* é invertebrado e não se enquadra nas regras para animais vertebrados.

## Créditos

Modelo e dados: Shiu et al. (2024); consórcio FlyWire (Dorkenwald et al., 2024; Schlegel et al., 2024; Eckstein et al., 2024). A versão inicial do código foi escrita com assistência de IA (Claude); o estudante revisa, executa, valida e estende cada parte. Licença MIT.
