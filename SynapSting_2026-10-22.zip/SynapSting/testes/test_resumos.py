import importlib.util
from pathlib import Path

import pytest
from pypdf import PdfReader

caminho = Path(__file__).parents[1] / "scripts" / "resumos.py"
spec = importlib.util.spec_from_file_location("resumos", caminho)
resumos = importlib.util.module_from_spec(spec)
spec.loader.exec_module(resumos)


def test_preencher_troca_as_lacunas():
    assert resumos.preencher("Olá, {aluno}!", {"aluno": "Ana"}) == "Olá, Ana!"


def test_preencher_avisa_quando_falta_valor():
    with pytest.raises(SystemExit, match="nao_existe"):
        resumos.preencher("{nao_existe}", {"aluno": "Ana"})


def test_formato_brasileiro_e_arredondamento():
    assert resumos.br(74.52) == "74,5"
    assert resumos.arred(80.5) == 81


def test_pdf_minimo_e_conferencia(tmp_path):
    cfg = {
        "documento": {"titulo": "Teste", "subtitulo": "Sub", "autoria": "{aluno}"},
        "bloco": [{"tipo": "paragrafo", "texto": "Olá, {aluno}."}],
    }
    pdf = tmp_path / "t.pdf"
    resumos.montar_pdf(cfg, {"aluno": "[Nome do aluno]"}, pdf)
    assert len(PdfReader(str(pdf)).pages) == 1
    assert any("colchetes" in p or "preencher" in p for p in resumos.conferir(pdf, max_paginas=1))
