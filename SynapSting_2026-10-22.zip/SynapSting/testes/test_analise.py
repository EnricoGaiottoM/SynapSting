import importlib.util
from pathlib import Path

import pandas as pd


def carregar(nome):
    caminho = Path(__file__).parents[1] / "scripts" / f"{nome}.py"
    spec = importlib.util.spec_from_file_location(nome, caminho)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


analisar = carregar("analisar")
resumos = carregar("resumos")


def test_read_usa_as_mesmas_tentativas_em_todas_as_condicoes(tmp_path):
    pd.DataFrame({"mode": "A", "level": ["0"] * 30, "trial": range(30), "MN9_hz": 1.0}).to_csv(
        tmp_path / "alimentacao.csv", index=False
    )
    d = analisar.read(tmp_path, "alimentacao")
    assert len(d) == analisar.TRIALS
    assert d.level.dtype == float


def test_triagem_em_partes_junta_um_unico_controle(tmp_path):
    pasta = tmp_path / "gargalos"
    pasta.mkdir()
    for parte, (fid, queda) in enumerate([(11, 10.0), (22, -2.0)]):
        pd.DataFrame(
            [
                dict(flywire_id="baseline", cell_type="", base_rate_hz=None, MN9_hz=60.0, drop_pct=0.0),
                dict(flywire_id=fid, cell_type="X", base_rate_hz=50.0, MN9_hz=54.0, drop_pct=queda),
            ]
        ).to_csv(pasta / f"gargalos_parte{parte}.csv", index=False)
    d = analisar.read_screen(tmp_path)
    assert (d.flywire_id.astype(str) == "baseline").sum() == 1
    assert len(d) == 3


def test_arquivos_derivados_ficam_em_analise_quando_a_pasta_existe(tmp_path):
    (tmp_path / "ajustes_modoA.csv").write_text("x")
    assert resumos.derivado(tmp_path, "ajustes_modoA.csv") == tmp_path / "ajustes_modoA.csv"
    (tmp_path / "analise").mkdir()
    (tmp_path / "analise" / "ajustes_modoA.csv").write_text("x")
    assert resumos.derivado(tmp_path, "ajustes_modoA.csv") == tmp_path / "analise" / "ajustes_modoA.csv"
