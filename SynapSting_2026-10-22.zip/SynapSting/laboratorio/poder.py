import argparse
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf

warnings.filterwarnings("ignore")

CONCENTRATIONS = np.array([1, 3, 10, 30, 100, 300, 1000], float)


def simulate_experiment(rng, n_flies, ratio, ec50_vehicle, sd_log10, slope):
    rows = []
    for group, shift in (("veiculo", 1.0), ("tratado", ratio)):
        centers = np.log10(ec50_vehicle * shift) + rng.normal(0, sd_log10, n_flies)
        for f, center in enumerate(centers):
            p = 1 / (1 + 10 ** (slope * (center - np.log10(CONCENTRATIONS))))
            responses = rng.random(len(CONCENTRATIONS)) < p
            rows += [(f"{group}_{f}", group, c, int(r)) for c, r in zip(CONCENTRATIONS, responses)]
    d = pd.DataFrame(rows, columns=["id_mosca", "grupo", "sacarose_mM", "resposta"])
    d["logc"] = np.log10(d.sacarose_mM)
    d["tratado"] = (d.grupo == "tratado").astype(int)
    return d


def detected(d, alpha):
    try:
        fit = smf.gee(
            "resposta ~ logc + tratado", "id_mosca", d, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()
        ).fit()
        return fit.params["tratado"] < 0 and fit.pvalues["tratado"] / 2 < alpha
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser(description="Poder estatístico do experimento de PER para cada número de moscas por grupo.")
    ap.add_argument("--sims", type=int, default=300)
    ap.add_argument("--alpha", type=float, default=0.05, help="nível do teste unilateral")
    ap.add_argument("--ec50", type=float, default=30.0)
    ap.add_argument("--sd", type=float, default=0.4)
    ap.add_argument("--slope", type=float, default=1.5)
    ap.add_argument("--n", type=int, nargs="+", default=[30, 45, 60, 80])
    ap.add_argument("--razoes", type=float, nargs="+", default=[1.5, 2.0, 2.5])
    ap.add_argument("--saida", default="resultados/final/poder/poder.csv")
    a = ap.parse_args()
    rng = np.random.default_rng(2026)
    rows = []
    for ratio in a.razoes:
        for n in a.n:
            hits = sum(detected(simulate_experiment(rng, n, ratio, a.ec50, a.sd, a.slope), a.alpha) for _ in range(a.sims))
            rows.append(dict(razao_ec50=ratio, moscas_por_grupo=n, poder=hits / a.sims, simulacoes=a.sims))
            print(f"razão {ratio}: n = {n} -> poder {hits / a.sims:.2f}", flush=True)
    Path(a.saida).parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(a.saida, index=False)


if __name__ == "__main__":
    main()
