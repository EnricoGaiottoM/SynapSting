#include <Servo.h>

const int SERVO_PIN = 9;
const int LED_PIN = 7;
const int SETTLE_MS = 250;

Servo arm;
int angleRest = 40;
int anglePresent = 95;

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  arm.attach(SERVO_PIN);
  arm.write(angleRest);
  Serial.println("PERBOT_READY");
}

void present(unsigned long durationMs) {
  arm.write(anglePresent);
  delay(SETTLE_MS);
  digitalWrite(LED_PIN, HIGH);
  Serial.print("ON ");
  Serial.println(millis());
  delay(durationMs);
  digitalWrite(LED_PIN, LOW);
  Serial.print("OFF ");
  Serial.println(millis());
  arm.write(angleRest);
  delay(SETTLE_MS);
  Serial.println("DONE");
}

void loop() {
  if (!Serial.available()) return;
  String command = Serial.readStringUntil('\n');
  command.trim();
  if (command.length() == 0) return;
  char op = command.charAt(0);
  long value = command.substring(1).toInt();
  if (op == 'P') {
    present(value > 0 ? value : 2000);
  } else if (op == 'A') {
    anglePresent = value;
    arm.write(anglePresent);
    Serial.println("OK");
  } else if (op == 'R') {
    angleRest = value;
    arm.write(angleRest);
    Serial.println("OK");
  } else if (op == '?') {
    Serial.print("rest=");
    Serial.print(angleRest);
    Serial.print(" present=");
    Serial.println(anglePresent);
  } else {
    Serial.println("ERR");
  }
}
